import javax.swing.*;
import java.awt.*;

public class BookingFormGUI extends JFrame{
    public BookingFormGUI(BookingSystem system){
        setTitle("Booking Form");
        setSize(400,300);
        setLayout(new GridLayout(6,2));

        JTextField name=new JTextField();
        JComboBox<String> day=new JComboBox<>(new String[]{"Saturday","Sunday"});
        JComboBox<String> lesson=new JComboBox<>(new String[]{"Yoga","Zumba","Box Fit","Aquacise","Body Blitz"});
        JComboBox<String> time=new JComboBox<>(new String[]{"Morning","Afternoon","Evening"});
        JLabel price=new JLabel();

        lesson.addActionListener(e->{
            String ex=(String)lesson.getSelectedItem();
            price.setText(system.prices.get(ex)+"");
        });

        JButton book=new JButton("Book");

        book.addActionListener(e->{
            Lesson l=system.find((String)day.getSelectedItem(),(String)time.getSelectedItem(),(String)lesson.getSelectedItem());
            if(l==null){JOptionPane.showMessageDialog(this,"Not found");return;}

            if(!l.book(name.getText())){
                JOptionPane.showMessageDialog(this,"Duplicate or Full");
            }else JOptionPane.showMessageDialog(this,"Booked");
        });

        add(new JLabel("Name"));add(name);
        add(new JLabel("Day"));add(day);
        add(new JLabel("Lesson"));add(lesson);
        add(new JLabel("Time"));add(time);
        add(new JLabel("Price"));add(price);
        add(new JLabel());add(book);

        setVisible(true);
    }
}