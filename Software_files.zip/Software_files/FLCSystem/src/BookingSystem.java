import java.util.*;

public class BookingSystem {
    List<Lesson> lessons = new ArrayList<>();
    Map<String, Double> prices = Map.of(
            "Yoga",10.0,"Zumba",12.0,"Box Fit",15.0,
            "Aquacise",8.0,"Body Blitz",14.0
    );

    public BookingSystem(){ generate(); }

    void generate(){
        String[] days={"Saturday","Sunday"};
        String[] times={"Morning","Afternoon","Evening"};
        String[] ex={"Yoga","Zumba","Box Fit","Aquacise","Body Blitz"};

        int i=0;
        for(int w=1;w<=8;w++){
            for(String d:days){
                for(String t:times){
                    String e=ex[i%ex.length];
                    lessons.add(new Lesson(e,d,t,prices.get(e)));
                    i++;
                }
            }
        }
    }

    public List<Lesson> getLessons(){ return lessons; }

    public Lesson find(String day,String time,String ex){
        for(Lesson l:lessons){
            if(l.day.equals(day)&&l.time.equals(time)&&l.exercise.equals(ex)) return l;
        }
        return null;
    }
}