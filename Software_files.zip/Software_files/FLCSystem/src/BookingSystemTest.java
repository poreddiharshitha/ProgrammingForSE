import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BookingSystemTest {

    // TEST 1: Successful booking
    @Test
    void testBookingSuccess() {
        BookingSystem system = new BookingSystem();
        Lesson lesson = system.getLessons().get(0);

        boolean result = lesson.book("Bob");

        assertTrue(result);
        assertEquals(1, lesson.members.size());
    }

    // TEST 2: Duplicate booking should fail
    @Test
    void testDuplicateBooking() {
        BookingSystem system = new BookingSystem();
        Lesson lesson = system.getLessons().get(0);

        lesson.book("Bob");
        boolean result = lesson.book("Bob");

        assertFalse(result);
    }

    // TEST 3: Max capacity (4 members)
    @Test
    void testMaxCapacity() {
        BookingSystem system = new BookingSystem();
        Lesson lesson = system.getLessons().get(0);

        lesson.book("A");
        lesson.book("B");
        lesson.book("C");
        lesson.book("D");

        boolean result = lesson.book("E");

        assertFalse(result);
        assertEquals(4, lesson.members.size());
    }

    // TEST 4: Review and average rating
    @Test
    void testReviewAverage() {
        Lesson lesson = new Lesson("Yoga", "Saturday", "Morning", 10);

        lesson.addReview(5, "Good");
        lesson.addReview(3, "Ok");

        assertEquals(4.0, lesson.avg());
    }
}