import java.util.*;

public class Lesson {
    String exercise,day,time;
    double price;
    List<String> members=new ArrayList<>();
    List<Review> reviews=new ArrayList<>();

    Lesson(String e,String d,String t,double p){exercise=e;day=d;time=t;price=p;}

    boolean book(String name){
        if(members.contains(name)) return false;
        if(members.size()>=4) return false;
        members.add(name);
        return true;
    }

    void addReview(int r,String c){reviews.add(new Review(r,c));}

    double avg(){return reviews.stream().mapToInt(x->x.rating).average().orElse(0);}

    public String getLatestComment() {
        if (reviews.isEmpty()) return "";
        return reviews.get(reviews.size() - 1).getComment();
    }
}