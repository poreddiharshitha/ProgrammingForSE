import javax.swing.*;
import java.awt.*;

public class MainMenuGUI extends JFrame {
    static BookingSystem system = new BookingSystem();

    public MainMenuGUI() {
        setTitle("FLC Main Menu");
        setSize(400, 300);
        setLayout(new GridLayout(3,1));

        JButton dayBtn = new JButton("Timetable by Day");
        JButton lessonBtn = new JButton("Timetable by Lesson");
        JButton viewBtn = new JButton("View Booking");
        JButton reportBtn = new JButton("Report");

        dayBtn.addActionListener(e -> new TimetableByDayGUI(system));
        lessonBtn.addActionListener(e -> new TimetableByLessonGUI(system));
        viewBtn.addActionListener(e -> new ViewBookingGUI(system));
        reportBtn.addActionListener(e -> new ReportGUI(system));

        add(dayBtn);
        add(lessonBtn);
        add(viewBtn);
        add(reportBtn);

        setLayout(new GridLayout(4,1));

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
}