import java.util.*;

public class Member {
    private String id;
    private String name;
    private List<Lesson> bookings = new ArrayList<>();

    public Member(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public List<Lesson> getBookings() { return bookings; }

    public boolean hasBooking(Lesson lesson) {
        return bookings.contains(lesson);
    }

    public void addBooking(Lesson lesson) {
        bookings.add(lesson);
    }

    public void removeBooking(Lesson lesson) {
        bookings.remove(lesson);
    }

    @Override
    public String toString() {
        return name;
    }
}