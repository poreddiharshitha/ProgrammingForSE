import javax.swing.*;
import java.awt.*;
import java.util.*;

public class ReportGUI extends JFrame {

    private BookingSystem system;

    public ReportGUI(BookingSystem system) {
        this.system = system;

        setTitle("Reports");
        setSize(400, 300);
        setLayout(new GridLayout(2,1));

        JButton report1 = new JButton("Report 1");
        JButton report2 = new JButton("Report 2");

        report1.addActionListener(e -> showReport1());
        report2.addActionListener(e -> showReport2());

        add(report1);
        add(report2);

        setVisible(true);
    }

    // ================= REPORT 1 =================
    private void showReport1() {

        String[] cols = {"Lesson", "Day", "Time", "Members", "Avg Rating"};

        Object[][] data = new Object[system.getLessons().size()][5];

        int i = 0;
        for (Lesson l : system.getLessons()) {
            data[i][0] = l.exercise;
            data[i][1] = l.day;
            data[i][2] = l.time;
            data[i][3] = l.members.size();
            data[i][4] = l.avg();
            i++;
        }

        JTable table = new JTable(data, cols);

        JFrame frame = new JFrame("Report 1");
        frame.setSize(700, 400);
        frame.add(new JScrollPane(table));
        frame.setVisible(true);
    }

    // ================= REPORT 2 =================
    private void showReport2() {

        Map<String, Double> incomeMap = new HashMap<>();

        // CALCULATE INCOME
        for (Lesson l : system.getLessons()) {
            double income = l.members.size() * l.price;
            incomeMap.put(l.exercise,
                    incomeMap.getOrDefault(l.exercise, 0.0) + income);
        }

        String[] cols = {"Exercise", "Total Income"};

        Object[][] data = new Object[incomeMap.size()][2];

        int i = 0;
        String maxExercise = "";
        double maxIncome = 0;

        for (String ex : incomeMap.keySet()) {
            double val = incomeMap.get(ex);

            data[i][0] = ex;
            data[i][1] = val;

            if (val > maxIncome) {
                maxIncome = val;
                maxExercise = ex;
            }

            i++;
        }

        JTable table = new JTable(data, cols);

        JFrame frame = new JFrame("Report 2");
        frame.setSize(500, 300);
        frame.setLayout(new BorderLayout());

        JLabel top = new JLabel("Highest Income: " + maxExercise + " (" + maxIncome + ")", JLabel.CENTER);

        frame.add(top, BorderLayout.NORTH);
        frame.add(new JScrollPane(table), BorderLayout.CENTER);

        frame.setVisible(true);
    }
}