import javax.swing.*;
import java.awt.*;

public class TimetableByDayGUI extends JFrame{
    public TimetableByDayGUI(BookingSystem system){
        setTitle("Timetable by Day");
        setSize(600,400);
        setLayout(new BorderLayout());

        String[] cols={"Day","Time","Lesson","Price"};
        Object[][] data=new Object[system.getLessons().size()][4];

        int i=0;
        for(Lesson l:system.getLessons()){
            data[i++]=new Object[]{l.day,l.time,l.exercise,l.price};
        }

        JTable table=new JTable(data,cols);
        JButton book=new JButton("Book Now");
        book.addActionListener(e->new BookingFormGUI(system));

        add(new JScrollPane(table),BorderLayout.CENTER);
        add(book,BorderLayout.SOUTH);
        setVisible(true);
    }
}