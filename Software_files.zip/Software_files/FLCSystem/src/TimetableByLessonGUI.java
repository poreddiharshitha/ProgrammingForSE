import javax.swing.*;
import java.awt.*;

public class TimetableByLessonGUI extends JFrame{
    public TimetableByLessonGUI(BookingSystem system){
        setTitle("Timetable by Lesson");
        setSize(600,400);

        String[] cols={"Lesson","Day","Time","Price"};
        Object[][] data=new Object[system.getLessons().size()][4];

        int i=0;
        for(Lesson l:system.getLessons()){
            data[i++]=new Object[]{l.exercise,l.day,l.time,l.price};
        }

        JTable table=new JTable(data,cols);
        JButton book=new JButton("Book Now");
        book.addActionListener(e->new BookingFormGUI(system));

        add(new JScrollPane(table),BorderLayout.CENTER);
        add(book,BorderLayout.SOUTH);
        setVisible(true);
    }
}