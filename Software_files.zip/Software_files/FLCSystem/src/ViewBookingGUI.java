import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.*;

public class ViewBookingGUI extends JFrame {

    private BookingSystem system;
    private JTable table;
    private DefaultTableModel model;
    private java.util.List<Lesson> bookedLessons;

    public ViewBookingGUI(BookingSystem system) {
        this.system = system;

        setTitle("View Bookings");
        setSize(900, 400);
        setLayout(new BorderLayout());

        loadTable();

        add(new JScrollPane(table), BorderLayout.CENTER);
        setVisible(true);
    }

    private void loadTable() {

        String[] cols = {"Lesson", "Day", "Time", "Members", "Avg Rating", "Comment", "Edit", "Review"};

        bookedLessons = new ArrayList<>();
        for (Lesson l : system.getLessons()) {
            if (l.members.size() > 0) {
                bookedLessons.add(l);
            }
        }

        Object[][] data = new Object[bookedLessons.size()][8];

        for (int i = 0; i < bookedLessons.size(); i++) {
            Lesson l = bookedLessons.get(i);
            data[i][0] = l.exercise;
            data[i][1] = l.day;
            data[i][2] = l.time;
            data[i][3] = l.members.size();
            data[i][4] = l.avg();
            data[i][5] = l.getLatestComment();
            data[i][6] = "Edit";
            data[i][7] = "Review";
        }

        model = new DefaultTableModel(data, cols) {
            public boolean isCellEditable(int row, int column) {
                return column >= 6;
            }
        };

        table = new JTable(model);

        table.getColumn("Edit").setCellRenderer(new ButtonRenderer());
        table.getColumn("Review").setCellRenderer(new ButtonRenderer());

        table.getColumn("Edit").setCellEditor(new ButtonEditor(new JCheckBox(), "edit"));
        table.getColumn("Review").setCellEditor(new ButtonEditor(new JCheckBox(), "review"));
    }

    // REFRESH TABLE AFTER ACTION
    private void refreshTable() {
        getContentPane().removeAll();
        loadTable();
        add(new JScrollPane(table), BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    // BUTTON RENDERER
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() { setOpaque(true); }

        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
            setText(value.toString());
            return this;
        }
    }

    // BUTTON EDITOR
    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String type;
        private int row;

        public ButtonEditor(JCheckBox checkBox, String type) {
            super(checkBox);
            this.type = type;
            button = new JButton();
            button.addActionListener(e -> fireEditingStopped());
        }

        public Component getTableCellEditorComponent(JTable table, Object value,
                                                     boolean isSelected, int row, int column) {
            this.row = row;
            button.setText(value.toString());
            return button;
        }

        public Object getCellEditorValue() {

            Lesson l = bookedLessons.get(row);

            if (type.equals("edit")) {
                String newDay = JOptionPane.showInputDialog("New Day:");
                String newTime = JOptionPane.showInputDialog("New Time:");

                if (newDay != null && newTime != null) {
                    l.day = newDay;
                    l.time = newTime;
                }

            } else if (type.equals("review")) {
                int rating = Integer.parseInt(JOptionPane.showInputDialog("Rating (1-5):"));
                String comment = JOptionPane.showInputDialog("Comment:");

                l.addReview(rating, comment);
            }

            refreshTable(); // 🔥 AUTO UPDATE TABLE

            return type.equals("edit") ? "Edit" : "Review";
        }
    }
}